create materialized view my_materialized_view as
SELECT employee.first_name,
       employee.last_name,
       employee.salary,
       min(employee.salary) OVER (PARTITION BY employee.company_id) AS min
FROM my_schema.employee;

alter materialized view my_materialized_view owner to postgres;

