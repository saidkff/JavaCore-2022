create view my_view(first_name, last_name, salary, min) as
SELECT employee.first_name,
       employee.last_name,
       employee.salary,
       min(employee.salary) OVER (PARTITION BY employee.company_id) AS min
FROM my_schema.employee;

alter table my_view
    owner to postgres;

